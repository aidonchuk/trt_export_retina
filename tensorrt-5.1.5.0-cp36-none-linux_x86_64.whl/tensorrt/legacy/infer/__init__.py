from .._deprecated_helpers import *
import tensorrt as trt
import numpy as np

warn_deprecated("The infer submodule will been removed in a future version of the TensorRT Python API")

"""
Foundational Types
"""
# DataType
DataType = trt.DataType
DataType.nptype = deprecated(lambda this: trt.nptype(this), use="tensorrt.nptype(datatype)")
DataType.input_type = deprecated(lambda this: trt.nptype(this), use="tensorrt.nptype(datatype)")
DataType.size = deprecated(lambda this: this.itemsize, use="itemsize")
# Weights
Weights = trt.Weights
@classmethod
def _empty(cls, dtype):
    warn_deprecated("You can construct an empty Weights object with tensorrt.Weights(dtype)")
    return trt.Weights(dtype)
Weights.empty = _empty
Weights.type = deprecated_property_readonly(lambda this: this.dtype, use="dtype")
Weights.values = deprecated_property_readonly(lambda this: this.numpy(), use="weights.numpy()")
Weights.count = deprecated_property_readonly(lambda this: this.size, use="size")
# Dims
Dims = trt.Dims
Dims.nbDims = deprecated_property_readonly(trt.Dims.__len__, use="len(dims) or dims.__len__()")
Dims.d = deprecated_property_readonly(lambda this: [elem for elem in this], reason="Dims is now iterable.", use="[] or __getitem__")
Dims.type = deprecated_property_readonly(lambda this: [this.get_type(index) for index in range(len(this))], use="dims.get_type(index)")
# Conversion functions
Dims.to_DimsNCHW = deprecated(lambda this: trt.DimsNCHW(this), reason="Dims can now be implicitly converted to DimsNCHW")
Dims.to_DimsCHW = deprecated(lambda this: trt.DimsCHW(this), reason="Dims can now be implicitly converted to DimsNCHW")
Dims.to_DimsHW = deprecated(lambda this: trt.DimsHW(this), reason="Dims can now be implicitly converted to DimsNCHW")
Dims.shape = deprecated(lambda this: tuple(elem for elem in this), reason="Dims now behaves like a tuple (and is implicitly convertible to/from Python iterables).")
# Dims2
Dims2 = trt.Dims2
# DimsHW
DimsHW = trt.DimsHW
DimsHW.H = deprecated(lambda this: this.h, use="h")
DimsHW.W = deprecated(lambda this: this.w, use="w")
DimsHW.area = deprecated(lambda this: trt.volume(this), use="tensorrt.volume")
# Dims3
Dims3 = trt.Dims3
# DimsCHW
DimsCHW = trt.DimsCHW
DimsCHW.C = deprecated(lambda this: this.c, use="c")
DimsCHW.H = deprecated(lambda this: this.h, use="h")
DimsCHW.W = deprecated(lambda this: this.w, use="w")
DimsCHW.vol = deprecated(lambda this: trt.volume(this), use="tensorrt.volume")
# Dims4
Dims4 = trt.Dims4
# DimsNCHW
DimsNCHW = trt.DimsNCHW
DimsNCHW.N = deprecated(lambda this: this.c, use="n")
DimsNCHW.C = deprecated(lambda this: this.c, use="c")
DimsNCHW.H = deprecated(lambda this: this.h, use="h")
DimsNCHW.W = deprecated(lambda this: this.w, use="w")
DimsNCHW.hvol = deprecated(lambda this: trt.volume(this), use="tensorrt.volume")
# DimensionType
DimensionType = trt.DimensionType
"""
Core
"""
# Builder
# TODO: Do IGpuAllocator legacy bindings.
Builder = trt.Builder
Builder.destroy = deprecated(lambda this: this.__del__(), use="del builder")
deprecated_getter_setter(Builder, "average_find_iterations")
deprecated_getter_setter(Builder, "debug_sync")
deprecated_getter_setter(Builder, "fp16_mode")
deprecated_getter_setter(Builder, "fp16_mode", "get_half2_mode", "set_half2_mode")
deprecated_getter_setter(Builder, "int8_mode")
deprecated_setter(Builder, "int8_calibrator")
deprecated_getter_setter(Builder, "max_batch_size")
deprecated_getter_setter(Builder, "max_workspace_size")
deprecated_getter_setter(Builder, "min_find_iterations")
deprecated_getter(Builder, "platform_has_fast_fp16", "platform_has_fast_fp16")
deprecated_getter(Builder, "platform_has_fast_int8", "platform_has_fast_int8")
deprecated_setter(Builder, "gpu_allocator")
create_infer_builder = lambda logger: trt.Builder(logger)
# Engine
CudaEngine = trt.ICudaEngine
CudaEngine.destroy = deprecated(lambda this: this.__del__(), use="del engine")
CudaEngine.get_binding_data_type = deprecated(trt.ICudaEngine.get_binding_dtype, use="get_binding_dtype")
CudaEngine.get_binding_dimensions = deprecated(trt.ICudaEngine.get_binding_shape, use="get_binding_shape")
deprecated_getter(CudaEngine, "device_memory_size")
deprecated_getter(CudaEngine, "location")
deprecated_getter(CudaEngine, "max_batch_size")
deprecated_getter(CudaEngine, "num_bindings", "get_nb_bindings")
deprecated_getter(CudaEngine, "num_layers", "get_nb_layers")
CudaEngine.get_workspace_size = deprecated(lambda this: this.max_workspace_size, use="max_workspace_size")
# Execution context
ExecutionContext = trt.IExecutionContext
ExecutionContext.destroy = deprecated(lambda this: this.__del__(), use="del context")
ExecutionContext.enqueue = deprecated(trt.IExecutionContext.execute_async, use="execute_async")
deprecated_getter_setter(ExecutionContext, "debug_sync")
deprecated_getter(ExecutionContext, "engine")
deprecated_getter_setter(ExecutionContext, "name")
deprecated_getter_setter(ExecutionContext, "profiler")
deprecated_setter(ExecutionContext, "device_memory")
# Runtime
Runtime = trt.Runtime
Runtime.destroy = deprecated(lambda this: this.__del__(), use="del runtime")
# Rebind deserialize engine to the one with a size argument. Because of the HostMemory trick below, .data() actually returns the buffer.
Runtime._deserialize_cuda_engine_impl = trt.Runtime.deserialize_cuda_engine

# We can't do plugin_factory=None as the default, because then there's no way to check
# if the user actually provided a None to the function.
# So instead, we default it to this dummy object. If isinstance(plugin_factory, DefaultObject)
# then we KNOW the user hasn't provided it explicitly (even as a None type).
class DefaultObject(object):
    pass

def runtime_deserialize_legacy(this, buf, size, plugin_factory=DefaultObject()):
    # If two arguments are given, assume the second one is the plugin_factory.
    # In case of three arguments, drop the middle argument.
    if isinstance(plugin_factory, DefaultObject):
        return this._deserialize_cuda_engine_impl(buf, size)
    else:
        return this._deserialize_cuda_engine_impl(buf, plugin_factory)

Runtime.deserialize_cuda_engine = runtime_deserialize_legacy

deprecated_setter(Runtime, "gpu_allocator")

create_infer_runtime = lambda logger: trt.Runtime(logger)
# IHostMemory
HostMemory = trt.IHostMemory
HostMemory.data = deprecated(lambda this: this)
deprecated_getter(HostMemory, "nbytes", getter_name="size")
deprecated_getter(HostMemory, "dtype", getter_name="type")
HostMemory.destroy = deprecated(lambda this: this.__del__(), use="del host_memory")
"""
Graph
"""
# Network Definition
NetworkDefinition = trt.INetworkDefinition
NetworkDefinition.destroy = deprecated(lambda this: this.__del__(), use="del network")
deprecated_getter_setter(NetworkDefinition, "pooling_output_dimensions_formula")
deprecated_getter_setter(NetworkDefinition, "convolution_output_dimensions_formula")
deprecated_getter_setter(NetworkDefinition, "deconvolution_output_dimensions_formula")
deprecated_getter(NetworkDefinition, "num_inputs", "get_nb_inputs")
deprecated_getter(NetworkDefinition, "num_layers", "get_nb_layers")
deprecated_getter(NetworkDefinition, "num_outputs", "get_nb_outputs")
NetworkDefinition.add_element_wise = deprecated(trt.INetworkDefinition.add_elementwise, use="network.add_elementwise")
NetworkDefinition.add_top_k = deprecated(trt.INetworkDefinition.add_topk, use="network.add_topk")
NetworkDefinition.add_ragged_soft_max = deprecated(trt.INetworkDefinition.add_ragged_softmax, use="network.add_ragged_softmax")
NetworkDefinition.add_rnnv2 = deprecated(trt.INetworkDefinition.add_rnn_v2, use="network.add_rnn_v2")
# Layer Type
LayerType = trt.LayerType
# Tensor
Tensor = trt.ITensor
deprecated_getter_setter(Tensor, "broadcast_across_batch")
deprecated_getter_setter(Tensor, "shape", getter_name="get_dimensions", setter_name="set_dimensions")
deprecated_getter_setter(Tensor, "location")
deprecated_getter_setter(Tensor, "name")
deprecated_getter_setter(Tensor, "dtype", getter_name="get_type", setter_name="set_type")
deprecated_getter(Tensor, "is_network_input", "is_network_input")
deprecated_getter(Tensor, "is_network_output", "is_network_output")
# Layer
Layer = trt.ILayer
deprecated_getter_setter(Layer, "core")
deprecated_getter_setter(Layer, "name")
deprecated_getter(Layer, "num_inputs", "get_nb_inputs")
deprecated_getter(Layer, "num_outputs", "get_nb_outputs")
deprecated_getter(Layer, "type")
# Convolution
ConvolutionLayer = trt.IConvolutionLayer
deprecated_getter_setter(ConvolutionLayer, "bias", "get_bias_weights", "set_bias_weights")
deprecated_getter_setter(ConvolutionLayer, "dilation")
deprecated_getter_setter(ConvolutionLayer, "kernel_size")
deprecated_getter_setter(ConvolutionLayer, "kernel", "get_kernel_weights", "set_kernel_weights")
deprecated_getter_setter(ConvolutionLayer, "num_groups", "get_nb_groups", "set_nb_groups")
deprecated_getter_setter(ConvolutionLayer, "num_output_maps", "get_nb_output_maps", "set_nb_output_maps")
deprecated_getter_setter(ConvolutionLayer, "padding")
deprecated_getter_setter(ConvolutionLayer, "stride")
# Fully Connected
FullyConnectedLayer = trt.IFullyConnectedLayer
deprecated_getter_setter(FullyConnectedLayer, "bias", "get_bias_weights", "set_bias_weights")
deprecated_getter_setter(FullyConnectedLayer, "kernel", "get_kernel_weights", "set_kernel_weights")
deprecated_getter_setter(FullyConnectedLayer, "num_output_channels", "get_nb_output_channels", "set_nb_output_channels")
# Activation
ActivationType = trt.ActivationType
ActivationLayer = trt.IActivationLayer
deprecated_getter_setter(ActivationLayer, "type", "get_activation_type", "set_activation_type")
# Pooling
PoolingType = trt.PoolingType
PoolingLayer = trt.IPoolingLayer
deprecated_getter_setter(PoolingLayer, "average_count_excludes_padding")
deprecated_getter_setter(PoolingLayer, "blend_factor")
deprecated_getter_setter(PoolingLayer, "padding")
deprecated_getter_setter(PoolingLayer, "type", "get_pooling_type", "set_pooling_type")
deprecated_getter_setter(PoolingLayer, "stride")
deprecated_getter_setter(PoolingLayer, "window_size")
# LRN
LRNLayer = trt.ILRNLayer
deprecated_getter_setter(LRNLayer, "alpha")
deprecated_getter_setter(LRNLayer, "beta")
deprecated_getter_setter(LRNLayer, "k")
deprecated_getter_setter(LRNLayer, "window_size")
# Scale
ScaleLayer = trt.IScaleLayer
ScaleMode = trt.ScaleMode
deprecated_getter_setter(ScaleLayer, "mode")
deprecated_getter_setter(ScaleLayer, "shift")
deprecated_getter_setter(ScaleLayer, "scale")
deprecated_getter_setter(ScaleLayer, "power")
# SoftMax
SoftmaxLayer = trt.ISoftMaxLayer
deprecated_getter_setter(SoftmaxLayer, "axes")
# Concatenation
ConcatenationLayer = trt.IConcatenationLayer
deprecated_getter_setter(ConcatenationLayer, "axis")
# Deconvolution
DeconvolutionLayer = trt.IDeconvolutionLayer
deprecated_getter_setter(DeconvolutionLayer, "bias", "get_bias_weights", "set_bias_weights")
deprecated_getter_setter(DeconvolutionLayer, "kernel_size")
deprecated_getter_setter(DeconvolutionLayer, "kernel", "get_kernel_weights", "set_kernel_weights")
deprecated_getter_setter(DeconvolutionLayer, "num_groups", "get_nb_groups", "set_nb_groups")
deprecated_getter_setter(DeconvolutionLayer, "num_output_maps", "get_nb_output_maps", "set_nb_output_maps")
deprecated_getter_setter(DeconvolutionLayer, "padding")
deprecated_getter_setter(DeconvolutionLayer, "stride")
# Elementwise
ElementWiseOperation = trt.ElementWiseOperation
ElementWiseLayer = trt.IElementWiseLayer
deprecated_getter_setter(ElementWiseLayer, "op", "get_operation", "set_operation")
# Shuffle
Permutation = trt.Permutation
class order(object):
    def __init__(self, perm):
        self.perm = perm

    def __getitem__(self, index):
        return self.perm[index]

    def __setitem__(self, index, val):
        self.perm[index] = val

Permutation.order = deprecated_property_readonly(lambda this: order(this), use="Permutation as a tuple/list instead.")
ShuffleLayer = trt.IShuffleLayer
deprecated_getter_setter(ShuffleLayer, "first_transpose")
deprecated_getter_setter(ShuffleLayer, "reshape_dims", "get_reshape_dimensions", "set_reshape_dimensions")
deprecated_getter_setter(ShuffleLayer, "second_transpose")
# Unary
UnaryOperation = trt.UnaryOperation
UnaryLayer = trt.IUnaryLayer
deprecated_getter_setter(UnaryLayer, "op", "get_operation", "set_operation")
# Plugin
PluginLayer = trt.IPluginLayer
deprecated_getter(PluginLayer, "plugin")
# Padding
PaddingLayer = trt.IPaddingLayer
deprecated_getter_setter(PaddingLayer, "pre_padding")
deprecated_getter_setter(PaddingLayer, "post_padding")
# RNN
RNNOperation = trt.RNNOperation
RNNDirection = trt.RNNDirection
RNNInputMode = trt.RNNInputMode
RNNLayer = trt.IRNNLayer
deprecated_getter_setter(RNNLayer, "bias")
deprecated_getter_setter(RNNLayer, "cell_state")
deprecated_getter_setter(RNNLayer, "data_length")
deprecated_getter_setter(RNNLayer, "direction")
deprecated_getter(RNNLayer, "hidden_size")
deprecated_getter(RNNLayer, "num_layers", "get_layer_count")
deprecated_getter_setter(RNNLayer, "hidden_state")
deprecated_getter_setter(RNNLayer, "input_mode")
deprecated_getter_setter(RNNLayer, "op", "get_operation", "set_operation")
deprecated_getter_setter(RNNLayer, "max_seq_length", "get_seq_length", "set_seq_length")
deprecated_getter_setter(RNNLayer, "weights")
# RNN V2
RNNGateType = trt.RNNGateType
RNNv2Layer = trt.IRNNv2Layer
deprecated_getter(RNNv2Layer, "num_layers", "get_layer_count")
deprecated_getter(RNNv2Layer, "hidden_size")
deprecated_getter_setter(RNNv2Layer, "seq_lengths", "get_sequence_lengths", "set_sequence_lengths")
deprecated_getter(RNNv2Layer, "max_seq_length")
deprecated_getter_setter(RNNv2Layer, "data_length")
deprecated_getter_setter(RNNv2Layer, "op", "get_operation", "set_operation")
deprecated_getter_setter(RNNv2Layer, "input_mode")
deprecated_getter_setter(RNNv2Layer, "direction")
deprecated_getter_setter(RNNv2Layer, "cell_state")
deprecated_getter_setter(RNNv2Layer, "hidden_state")
# Plugin
PluginLayer = trt.IPluginLayer
# Constant
ConstantLayer = trt.IConstantLayer
deprecated_getter_setter(ConstantLayer, "weights")
deprecated_getter_setter(ConstantLayer, "shape", "get_dimensions", "set_dimensions")
# Gather
GatherLayer = trt.IGatherLayer
deprecated_getter_setter(GatherLayer, "axis", "get_gather_axis", "set_gather_axis")
# TopK
TopKOperation = trt.TopKOperation
TopKLayer = trt.ITopKLayer
deprecated_getter_setter(TopKLayer, "op", "get_operation", "set_operation")
deprecated_getter_setter(TopKLayer, "k")
deprecated_getter_setter(TopKLayer, "axes", "get_reduce_axes", "set_reduce_axes")
# MatrixMultiply
MatrixMultiplyLayer = trt.IMatrixMultiplyLayer
MatrixMultiplyLayer.set_transpose = deprecated(lambda this, index, val: setattr(this, "transpose0" if index == 0 else "transpose1", val), use="transpose0 or transpose1")
MatrixMultiplyLayer.get_transpose = deprecated(lambda this, index: this.transpose0 if index == 0 else this.transpose1, use="transpose0 or transpose1")
# RaggedSoftMax
RaggedSoftMaxLayer = trt.IRaggedSoftMaxLayer
# Reduce
ReduceOperation = trt.ReduceOperation
ReduceLayer = trt.IReduceLayer
deprecated_getter_setter(ReduceLayer, "op", "get_operation", "set_operation")
deprecated_getter_setter(ReduceLayer, "axes", "get_reduce_axes", "set_reduce_axes")
deprecated_getter_setter(ReduceLayer, "keep_dims", "get_keep_dimensions", "set_keep_dimensions")


# Logger
Logger = trt.Logger
ConsoleLogger = trt.Logger
ColorLogger = trt.Logger
LogSeverity = trt.Logger.Severity

# Profiler
Profiler = trt.Profiler
ConsoleProfiler = trt.Profiler
ConsoleProfiler.mProfile = None
ConsoleProfiler.timing_iterations = None
# Int8
CalibrationAlgoType = trt.CalibrationAlgoType
Int8Calibrator = trt.IInt8Calibrator
Calibrator = trt.IInt8Calibrator
# Int8 Entropy
Int8EntropyCalibrator = trt.IInt8EntropyCalibrator
EntropyCalibrator = trt.IInt8EntropyCalibrator
# Int8 Legacy
Int8LegacyCalibrator = trt.IInt8LegacyCalibrator
LegacyCalibrator = trt.IInt8LegacyCalibrator
